package com.jfinalDemo.config;



import com.jfinal.config.Constants;
import com.jfinal.config.Handlers;
import com.jfinal.config.Interceptors;
import com.jfinal.config.JFinalConfig;
import com.jfinal.config.Plugins;
import com.jfinal.config.Routes;
import com.jfinal.ext.handler.ContextPathHandler;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.ActiveRecordPlugin;
import com.jfinal.plugin.druid.DruidPlugin;
import com.jfinal.render.ViewType;
import com.jfinal.template.Engine;
import com.jfinalDemo.controller.GetParamController;
import com.jfinalDemo.controller.HelloWorldController;
import com.jfinalDemo.controller.UserController;
import com.jfinalDemo.model.User;
import com.sun.xml.internal.ws.transport.http.HttpAdapter;

public class Config extends JFinalConfig{

	@Override
	public void configConstant(Constants me) {
		//加载数据库文件
		loadPropertyFile("little_config.txt");
		me.setDevMode(getPropertyToBoolean("devMode", true));
		me.setViewType(ViewType.FREE_MARKER);
	}

	@Override
	public void configRoute(Routes me) {
		me.add("/", HelloWorldController.class);
		me.add("/param", GetParamController.class);
		me.add("/user", UserController.class);
	}

	@Override
	public void configPlugin(Plugins me) {
		String username = getProperty("user");
		String password =  getProperty("password");
		//jdbc组件,功能等同于c3p0,DBCP
		DruidPlugin druid = new DruidPlugin(getProperty("jdbcUrl"), username, password);
		//添加连接池
		me.add(druid);
		ActiveRecordPlugin arp = new ActiveRecordPlugin(druid);
		me.add(arp);   //接入ActiveRecord插件
		//将实体类与模型类映射
		arp.addMapping("t_user", User.class);
	}

	@Override
	public void configInterceptor(Interceptors me) {
		
	}

	@Override
	public void configHandler(Handlers me) {
		//设置上下文路径
		me.add(new ContextPathHandler("contextPath"));
	}

}
