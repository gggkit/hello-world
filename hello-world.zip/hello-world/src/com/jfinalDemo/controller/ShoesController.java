package com.jfinalDemo.controller;

import com.jfinal.core.Controller;

/**
 * 鞋服出货管理
 * 
 * @author Administrator
 *
 */
public class ShoesController extends Controller{

	public void index(){
		
	}
	
	public void addShoes(){
		
	}
	
	public void doAddShoes(){
		
	}
	
	public void queryShoesById(){
		
	}
	
	public void updateShoes(){
		
	}
	
	public void deleteById(){
		
	}
}
