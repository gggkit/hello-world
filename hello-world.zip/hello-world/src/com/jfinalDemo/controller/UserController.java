package com.jfinalDemo.controller;

import java.util.List;

import com.jfinal.core.Controller;
import com.jfinalDemo.model.User;

/**
 * 用户controller
 * 
 * @author Administrator
 *
 */
public class UserController extends Controller{

	
	/**
	 * 显示用户
	 */
	public void index(){
		String sql = "select * from t_user order by id desc";
		User user = getModel(User.class);
		List<User> users = user.find(sql);
		setAttr("objectlist", users);
		renderFreeMarker("index.html");
	}
	
	/**
	 * 去添加页面
	 */
	public void addUser(){
		renderFreeMarker("addUser.html");
	}
	
	/**
	 * 处理添加的操作
	 */
	public void doAddUser(){
		User user = getModel(User.class);
		boolean flag = user.save();
		if (flag) {
			//重定向到index页面
			redirect("/user/");
		}else {
			//返回错误提示
			renderText("Sorry,操作失败!!!");
		}
	}
	
	
	/**
	 * 去修改页面(通过ID查询到要修改的user信息,回现给修改的页面)
	 */
	public void queryUserById(){
		int id  = getParaToInt(0);
		System.out.println(id);
		String sql = "select * from t_user where id = ?";
		User user = getModel(User.class);
		List<User> find = user.find(sql, id);
		//将查询的结果返回给updateUser.html,因为id只有一个,所以find里只有一条User信息
		setAttr("user", find.get(0));
		renderFreeMarker("updateUser.html");
	}
	
	/**
	 * 修改的方法
	 */
	public void updateUser(){
		User user = getModel(User.class);
		boolean flag = user.update();
		if (flag) {
			//重定向到index页面
			redirect("/user/");
//			forwardAction("/user/");
		}else {
			//返回错误提示
			renderText("Sorry,操作失败!!!");
		}
	}
	
	
	/**
	 * 根据ID删除
	 */
	public void deleteById(){
		int id = getParaToInt(0);
		User user= getModel(User.class);
		boolean flag = user.deleteById(id);
		if (flag) {
			//重定向到index页面
			redirect("/user/");
		}else {
			//返回错误提示
			renderText("Sorry,操作失败!!!");
		}
	}
}
