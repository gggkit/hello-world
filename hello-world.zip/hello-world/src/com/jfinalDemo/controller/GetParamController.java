package com.jfinalDemo.controller;

import com.jfinal.core.Controller;

/**
 * 获取参数
 * 
 * @author gml
 * @version 1.0 , 2017年6月26日22:53:57
 */
public class GetParamController extends Controller{

	public void index(){
		renderFreeMarker("param.html");
	}
	
	public void post(){
		String username = getPara("username");
		String password = getPara("password");
		System.out.println(username);
		System.out.println(password);
		setAttr("msg", "接收成功!!!");
		renderFreeMarker("param.html");
	}
	
	public void get1(){
		int id = getParaToInt(0);
		System.out.println(id);
		setAttr("msg", "接收成功!");
		renderFreeMarker("param.html");
	}
	
	public void get2(){
		String iid = getPara(1);
		System.out.println(iid);
		String id2 = getPara(2);
		System.out.println(id2);
		setAttr("msg", "接收成功");
		renderFreeMarker("param.html");
	}
}

