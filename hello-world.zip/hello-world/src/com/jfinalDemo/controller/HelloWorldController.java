package com.jfinalDemo.controller;

import com.jfinal.core.Controller;

public class HelloWorldController extends Controller{

	public void index(){
		String msg = "nihao jfinal!!!!";
		setAttr("helloworld", msg);
		renderFreeMarker("helloworld.html");
	}
}
