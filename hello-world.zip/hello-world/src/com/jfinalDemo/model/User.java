package com.jfinalDemo.model;

import java.util.Map;

import com.jfinal.plugin.activerecord.Model;


/**
 * 用户模型
 * 
 * @author gml
 *
 */
public class User extends Model<User>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public static User user=new User();

	public Map<String, Object> getAttrs(){
		return super.getAttrs();
	}

}
